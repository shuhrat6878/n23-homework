// let a = 15, b = 45, c = 22
// console.log(a + b + c);


//2-vazifa
// let yosh = prompt("yilingizni kirgazing");
// let javob = 2025 - yosh;
// console.log(javob);


// 3-vazifa
// let son = prompt("son kirgazing"), b = prompt("daraja kirgazing");
// console.log(son**b);


// 4-vazifa
// let a = 10;
// let b = 5;
// let kattasi = Math.max(a, b);
// console.log("kattasi: " + kattasi);

 // 5- masala
// let son = 50, foiz = 25;
// let foizi = (foiz * son) /100;
// console.log(foizi);

// 6-vazifa
// let radus=5,PI =3.14
// let yuza = PI * (radus ^ 2)
// console.log(yuza);


 // 7-vazifa
// let harorat = 44, farangeyt = (harorat * 9 / 5 + 32);
// console.log(farangeyt);

// 8 - vazifa
// let a = 23, b = 34
// const peremetr = (a + b) * 2
// console.log(peremetr);


// qoshimcha.. tezlikni topish
// let vaqt = 45, soat = vaqt / 60
// let  yol = 25
//  let v = yol / soat;
// console.log(v);


